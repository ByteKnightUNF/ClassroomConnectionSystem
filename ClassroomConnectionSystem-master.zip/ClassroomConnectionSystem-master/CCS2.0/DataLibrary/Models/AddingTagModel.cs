﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.Models
{
   public class AddingTagModel
    {
        public int Photo_id { get; set; }

        public int Tag { get; set; }

        public string Name { get; set; }

    }
}
